Bootstrap Slider
=============

Fork of eyecon's [bootstrap-slider](http://www.eyecon.ro/bootstrap-slider/).

Specially remastered for iLIME Project @ UNIR Research. More info: 
[http://blogs.unir.net/elearning/telsock-research-group/](http://)

![ScreenShot](https://raw.github.com/pammacdotnet/bootstrap-slider/master/locks.png)

Changes
----------
Current changes include:

+ Better responsive support
+ Updated look and feel
+ Minor layout tweaks
+ Removed built-in handle types
+ Bower install
+ Limits and locks 


	



