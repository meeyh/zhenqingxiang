<?php

return [
    'Pid'        => '父ID',
    'Name'       => '规则',
    'Title'      => '标题',
    'Remark'     => '备注',
    'Ismenu'     => '是否菜单',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Menu tips'  => '规则任意,请不可重复,仅做层级显示,无需匹配控制器和方法',
    'Node tips'  => '模块/控制器/方法名',
    'Weigh'      => '权重',
    'Status'     => '状态'
];
